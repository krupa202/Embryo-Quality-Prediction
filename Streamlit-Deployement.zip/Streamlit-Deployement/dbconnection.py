import streamlit as st
import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image
from PIL import Image
import cv2
import base64
import mysql.connector

# Helper function for converting image to base64
def image_to_base64(img_array):
    _, buffer = cv2.imencode('.jpg', img_array)
    return base64.b64encode(buffer).decode()

# Page Config
st.set_page_config(page_title="Embryo Stage & Quality Classifier", page_icon="🧬", layout="wide")

# Custom CSS Styling
st.markdown("""
    <style>
    h1 {
        font-size: 55px !important;
        color: #1F618D;
        text-align: center;
    }
    h2 {
        font-size: 35px !important;
        color: #117A65;
        margin-top: 2rem;
    }
    .upload-heading {
        font-size: 28px;
        font-weight: bold;
        color: #154360;
        text-align: center;
        margin-bottom: 0.5rem;
    }
    .prediction {
        font-size: 24px;
        font-weight: bold;
        color: #D35400;
        text-align: center;
        margin-top: 1rem;
    }
    .highlight {
        color: #C0392B;
        font-weight: bold;
        font-size: 20px;
        text-align: center;
    }
    .confidence {
        color: #5D6D7E;
        font-weight: bold;
        font-size: 22px;
        text-align: center;
        margin-top: 0.5rem;
    }
    .predicted-button {
        background-color: #3498DB;
        color: white;
        padding: 0.5em 1em;
        border: none;
        border-radius: 10px;
        font-size: 20px;
        margin-top: 1rem;
        display: block;
        margin-left: auto;
        margin-right: auto;
    }
    .block-container {
        padding-top: 2rem;
    }
    </style>
""", unsafe_allow_html=True)

# Load your Model (update path if needed)
model = tf.keras.models.load_model(r"E:\360_proj2_details\ResNet_Model_Building\resnet152_embryo_model.h5")

# Class Labels
class_names = ['8-cells_Grade-A', '8-cells_Grade-B', '8-cells_Grade-C',
               'Blastocyst_Grade-A', 'Blastocyst_Grade-B', 'Blastocyst_Grade-C',
               'Non-Embryo', 'morula_Grade-A', 'morula_Grade-B', 'morula_Grade-C']

# MySQL Insertion
def insert_predictions(patient_id, Day_3, Day_4, Day_5):
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="user1",
            password="Krupasagar@123",
            database="embryo_pred"
        )
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO embryo_qual_pred (patient_Id, Day_3, Day_4, Day_5) VALUES (%s, %s, %s, %s)",
            (patient_id, Day_3, Day_4, Day_5)
        )
        conn.commit()
        conn.close()
        st.success("✅ Data successfully stored in the database.")
    except Exception as e:
        st.error(f"❌ Database Error: {e}")

# Login Page
def login():
    st.title("Embryo Classifier Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        if username == "user" and password == "password@123":
            st.session_state["authenticated"] = True
            st.rerun()
  # Fixes double-click issue
        else:
            st.error("Incorrect username or password.")


# Main Application
def main_app():
    st.title("🧬 Embryo Stage & Quality Classifier")
    
    st.markdown("### 🆔 Enter Patient ID", unsafe_allow_html=True)
    patient_id = st.text_input("Patient ID", max_chars=20)

    # Upload Section
    st.markdown("<h2>Upload Your Embryo Images:</h2>", unsafe_allow_html=True)

    upload_cols = st.columns(3)

    with upload_cols[0]:
        st.markdown('<div class="upload-heading">🔵 Day 3 - 8-Cell</div>', unsafe_allow_html=True)
        day3_img = st.file_uploader("", type=["jpg", "jpeg", "png"], key="8cell")
    with upload_cols[1]:
        st.markdown('<div class="upload-heading">🟣 Day 4 - Morula</div>', unsafe_allow_html=True)
        day4_img = st.file_uploader("", type=["jpg", "jpeg", "png"], key="morula")
    with upload_cols[2]:
        st.markdown('<div class="upload-heading">🟢 Day 5 - Blastocyst</div>', unsafe_allow_html=True)
        day5_img = st.file_uploader("", type=["jpg", "jpeg", "png"], key="blastocyst")

    uploaded_files = [day3_img, day4_img, day5_img]
    labels = ["Day 3", "Day 4", "Day 5"]
    day_labels = []

    if all(uploaded_files):
        st.markdown("---")
        st.markdown(f"<h3 style='color:#1A5276; text-align:center;'>🆔 Patient ID: <span style='color:#117864'>{patient_id}</span></h3>", unsafe_allow_html=True)
        st.markdown('<h2>🔍 Embryo Quality Assessment Results</h2>', unsafe_allow_html=True)

        day_cols = st.columns(3)

        for idx, (uploaded_file, label) in enumerate(zip(uploaded_files, labels)):
            if uploaded_file is not None:
                img = Image.open(uploaded_file).convert("RGB")
                img_resized = img.resize((224, 224))
                img_array = image.img_to_array(img_resized) / 255.0
                img_array = np.expand_dims(img_array, axis=0)

                predictions = model.predict(img_array)
                pred_index = np.argmax(predictions[0])
                predicted_class = class_names[pred_index]
                confidence_score = predictions[0][pred_index] * 100

                day_labels.append(predicted_class)

                img_cv = np.array(img)
                img_cv = cv2.cvtColor(img_cv, cv2.COLOR_RGB2BGR)

                last_conv_layer_name = "conv5_block3_out"
                grad_model = tf.keras.models.Model(
                    [model.inputs],
                    [model.get_layer(last_conv_layer_name).output, model.output]
                )

                with tf.GradientTape() as tape:
                    conv_outputs, preds = grad_model(img_array)
                    class_channel = preds[:, pred_index]

                grads = tape.gradient(class_channel, conv_outputs)
                pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))
                conv_outputs = conv_outputs[0]
                heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
                heatmap = tf.squeeze(heatmap)
                heatmap = np.maximum(heatmap, 0) / tf.math.reduce_max(heatmap)
                heatmap = heatmap.numpy()

                heatmap = cv2.resize(heatmap, (img_cv.shape[1], img_cv.shape[0]))
                heatmap = np.uint8(255 * heatmap)
                heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
                superimposed_img = cv2.addWeighted(img_cv, 0.6, heatmap, 0.4, 0)

                with day_cols[idx]:
                    st.markdown(f"<div style='font-size: 28px; color: blue; font-weight: bold; text-align: center;'>{label}</div>", unsafe_allow_html=True)

                    img_cols = st.columns(2)
                    with img_cols[0]:
                        st.image(cv2.cvtColor(img_cv, cv2.COLOR_BGR2RGB), caption="Original Image", use_container_width=True)
                    with img_cols[1]:
                        st.image(cv2.cvtColor(superimposed_img, cv2.COLOR_BGR2RGB), caption="Grad-CAM", use_container_width=True)

                    st.markdown(f"""
                    <button class="predicted-button">Predicted Class</button>
                    <div class="highlight">{predicted_class}</div>
                    <div class="confidence">Confidence: {confidence_score:.2f}%</div>
                    """, unsafe_allow_html=True)

        if patient_id.strip() != "":
            insert_predictions(patient_id, day_labels[0], day_labels[1], day_labels[2])
        else:
            st.warning("⚠ Please enter a valid Patient ID before proceeding.")
    else:
        st.info("ℹ Please upload all three images to view the results.")

# Session Handling
if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False

if not st.session_state["authenticated"]:
    login()
else:
    main_app()
