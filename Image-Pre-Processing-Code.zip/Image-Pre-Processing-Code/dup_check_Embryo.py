import os
import hashlib
from PIL import Image

def get_image_hash(image_path):
    with Image.open(image_path) as img:
        img = img.resize((100, 100)).convert("L")  # Resize and convert to grayscale
        return hashlib.md5(img.tobytes()).hexdigest()

def find_duplicates(folder_path):
    hashes = {}
    duplicates = []

    for filename in os.listdir(folder_path):
        if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
            path = os.path.join(folder_path, filename)
            img_hash = get_image_hash(path)
            if img_hash in hashes:
                duplicates.append((filename, hashes[img_hash]))
            else:
                hashes[img_hash] = filename

    return duplicates

# Example usage
folder = r"E:\krupa\Grading\Grades\Morula\C"
dupes = find_duplicates(folder)

if dupes:
    print("Duplicate images found:")
    cnt = 0
    for dup, original in dupes:
        cnt+=1
    print(cnt)
        
else:
    print("No duplicate images found.")
