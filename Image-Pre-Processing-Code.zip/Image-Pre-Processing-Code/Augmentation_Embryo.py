import os
from PIL import Image
import torchvision.transforms as transforms
import random

# Folder containing original images
image_dir = r"E:\krupa\Grading\Grades\Non-Embryo"
images = [f for f in os.listdir(image_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

# Define augmentations
augmentations = [
    transforms.RandomHorizontalFlip(p=1),
    transforms.RandomVerticalFlip(p=1),
    transforms.RandomRotation(90),
    transforms.RandomRotation(180),
    transforms.RandomRotation(270)
]

# Resize transform
resize = transforms.Resize((224, 224))

# Total desired images
target_count = 1000
current_count = len(images)
extra_needed = target_count - current_count

print(f"Original images: {current_count}")
print(f"Generating {extra_needed} augmented images...")

save_count = 0
i = 0

while save_count < extra_needed:
    img_name = images[i % current_count]
    img_path = os.path.join(image_dir, img_name)
    img = Image.open(img_path).convert("RGB")
    
    for aug in random.sample(augmentations, 3):  # randomly pick 3 augmentations
        if save_count >= extra_needed:
            break
        aug_img = resize(aug(img))
        new_name = f"aug_{save_count}_{img_name}"
        aug_img.save(os.path.join(image_dir, new_name))
        save_count += 1

    i += 1

print("Augmentation completed. Final image count:", len(os.listdir(image_dir)))
